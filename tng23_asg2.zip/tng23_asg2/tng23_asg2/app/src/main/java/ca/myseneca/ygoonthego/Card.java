package ca.myseneca.ygoonthego;


import android.graphics.Bitmap;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;

public class Card {

    //Card properties
    public String name;
    public String cardText;
    public String type; //monster, spell, trap

    public String monster_type; //warrior, spellcaster etc.
    public String attribute; //'family' in the api

    public String property; //e.g. counter trap, quickplay spell

    public int level;
    public int atk;
    public int def;

    public Bitmap cardImage;


    //Card prices
    double high;
    double avg;
    double low;

    double high_cad;
    double avg_cad;
    double low_cad;


    //other
    String message;
    String success;


    Card() {
        high = -0.01;
        avg = -0.01;
        low = -0.01;
    }

    //accepts a string assumed to be in json format and parses it for its values
    public boolean parseToCard(String result) {

        boolean status = true;

        try {

            JSONObject json = new JSONObject(result);

            success = json.getString("status");

            if (success.equals("success")) {
                /*
                https://stackoverflow.com/questions/26653215/android-parsing-nested-json-objects
                 */

                type = json.getJSONObject("data").getString("card_type");

                if (type.equals("monster")) {

                    name = json.getJSONObject("data").getString("name");
                    cardText = json.getJSONObject("data").getString("text");
                    monster_type = json.getJSONObject("data").getString("type");
                    attribute = json.getJSONObject("data").getString("family");

                    level = json.getJSONObject("data").getInt("level");
                    atk = json.getJSONObject("data").getInt("atk");
                    def = json.getJSONObject("data").getInt("def");


                } else if (type.equals("spell")) {

                    name = json.getJSONObject("data").getString("name");
                    cardText = json.getJSONObject("data").getString("text");
                    property = json.getJSONObject("data").getString("property");
                    attribute = "spell";


                } else if (type.equals("trap")) {

                    name = json.getJSONObject("data").getString("name");
                    cardText = json.getJSONObject("data").getString("text");
                    property = json.getJSONObject("data").getString("property");
                    attribute = "trap";

                } else {
                    Log.e(">", "Unknown card type.");
                    Log.e(">","Card type=" + type);
                }

            } else if (success.equals("fail")) {
                message = json.getString("message");
                Log.d(">","Failed to find card. Reason: " + message);
                //Toast.makeText(getApplicationContext(), "Failed to find card. Reason: " + message, Toast.LENGTH_LONG).show();
                status = false;

            } else {
                Log.e(">","Success was neither a success nor failure");
                Log.e(">","success='" + success + "'");
                status = false;
            }


        } catch (JSONException e) {
            e.printStackTrace();
        }

        return status;
    }

    //accepts a string assumed to be in json format and parses it for its current prices
    public void parsePricesToCard(String result) {
        //due to varying complications, the method sets only the lowest 'low','average' and 'high' prices

        try {
            JSONObject layer1 = new JSONObject(result); //layer 1 is the success/fail status of query
            success = layer1.getString("status");

            if (success.equals("success")) {
                /*
                https://stackoverflow.com/questions/17136769/how-to-parse-jsonarray-in-android
                 */

                JSONArray layer2 = layer1.getJSONArray("data"); //layer 2 is an array of the sets containing the card

                double lowestLow = 0.00;
                double lowestAvg = 0.00;
                double lowestHigh = 0.00;

                for (int i = 0; i < layer2.length(); i++) {

                    JSONObject layer3 = layer2.getJSONObject(i); //layer 3 is the price data for the set
                    JSONObject layer4 = layer3.getJSONObject("price_data"); //layer 4 contains info on the set
                    JSONObject layer5 = layer4.getJSONObject("data"); //layer 5 contains the success/fail status of querying the price
                    JSONObject prices = layer5.getJSONObject("prices"); //layer 6 includes calculated and raw data for the price

                    lowestLow = prices.getDouble("low");
                    lowestAvg = prices.getDouble("average");
                    lowestHigh = prices.getDouble("high");

                    if ((low < 0)||(lowestLow < low)) {
                        low = lowestLow;
                    }

                    if ((avg < 0)||(lowestAvg < avg)) {
                        avg = lowestAvg;
                    }

                    if ((high < 0)||(lowestHigh < high)) {
                        high = lowestHigh;
                    }

                }

                Log.d(">","Card low: " + String.valueOf(low) +
                        " Card avg: " + String.valueOf(avg) +
                        " Card high: " + String.valueOf(high));

            } else {
                Log.e(">", "Could not get price. Server replied: " + layer1.getString("message"));
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    //Accepts a conversion rate (CAD -> USD) and sets the cad prices
    void updateCadPrices(double rate) {

        double inverse = 1/rate;

        low_cad = low * inverse;
        avg_cad = avg * inverse;
        high_cad = high * inverse;

    }

}
