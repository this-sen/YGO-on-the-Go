package ca.myseneca.ygoonthego;

import android.app.AlertDialog;
import android.app.SearchManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    //offline list of card names
    String[] cardNameDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        cardNameDb = getResources().getStringArray(R.array.cards);
        ListView lv = (ListView) findViewById(R.id.listView);
        ArrayAdapter aa = new ArrayAdapter(this, R.layout.activity_listview, cardNameDb);
        lv.setAdapter(aa);


        //Queries when item in listview is tapped
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView parent, View view, int position, long id) {
                String temp = ((TextView) view).getText().toString();

                displayCard(temp);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);

        /*
        https://developer.android.com/guide/topics/search/search-dialog.html
         */
        /*
        SearchManager sm = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        SearchView sv = (SearchView) menu.findItem(R.id.searchBox).getActionView();
        sv.setSearchableInfo(sm.getSearchableInfo(getComponentName()));
        */
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_toggleView) {
            toggleView();
        } else if (id == R.id.about) {
            displayAbout();
        }

        return super.onOptionsItemSelected(item);
    }

    //Starts the activity to query and display the card
    void displayCard(String cardname) {

        /*
            https://stackoverflow.com/questions/2405120/how-to-start-an-intent-by-passing-some-parameters-to-it
        */
        Intent intent = new Intent(this, CardDisplayActivity.class);
        intent.putExtra("query", cardname);
        startActivity(intent);
    }

    //Popup message
    void displayAbout() {
        AlertDialog.Builder adb = new AlertDialog.Builder(this)
                .setTitle("About")
                .setMessage("YGO on the Go is a Yu-Gi-Oh! card database app made possible with the YugiohPrices API." +
                                "\n\n" +
                                "Visit them at:\n" +
                                "http://www.yugiohprices.com/\n" +
                                "View the API at:\n" +
                                "http://docs.yugiohprices.apiary.io/" +
                                "\n\n" +
                                "Offline card name database from YGOPRO 1.033.7 V2 Percy:\n" +
                                "http://www.ygopro.co/" +
                                "\n\n" +
                                "API for conversion rates by fixer.io:\n" +
                                "http://fixer.io/"
                )
                .setPositiveButton("Close", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //finish();
                    }
                });
        adb.show();
    }

    //Does nothing in this activity
    void toggleView() {
        Toast.makeText(getApplicationContext(), "Search a card first!", Toast.LENGTH_SHORT).show();
    }

}
