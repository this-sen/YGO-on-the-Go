package ca.myseneca.ygoonthego;

import android.app.AlertDialog;
import android.app.SearchManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.SearchView;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;

public class CardDisplayActivity extends AppCompatActivity {

    Card card;
    boolean viewPrices;

    final String cardDataUrl = "http://www.yugiohprices.com/api/card_data/";
    final String cardImageUrl = "http://www.yugiohprices.com/api/card_image/";
    final String cardPriceUrl = "http://www.yugiohprices.com/api/get_card_prices/";
    String query;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_display);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        card = new Card();
        viewPrices = false; //true for trader, false for player



        Intent intent = getIntent();
        query = intent.getStringExtra("query"); //card to search
        Log.d(">","Query: " + query);
        queryCard(query);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_toggleView) {
            toggleView();
        } else if (id == R.id.about) {
            displayAbout();
        }

        return super.onOptionsItemSelected(item);
    }

    //Popup message
    void displayAbout() {
        AlertDialog.Builder adb = new AlertDialog.Builder(this)
                .setTitle("About")
                .setMessage("YGO on the Go is a Yu-Gi-Oh! card database app made possible with the YugiohPrices API." +
                                "\n\n" +
                                "Visit them at:\n" +
                                "http://www.yugiohprices.com/\n" +
                                "View the API at:\n" +
                                "http://docs.yugiohprices.apiary.io/" +
                                "\n\n" +
                                "Offline card name database from YGOPRO 1.033.7 V2 Percy:\n" +
                                "http://www.ygopro.co/" +
                                "\n\n" +
                                "API for conversion rates by fixer.io:\n" +
                                "http://fixer.io/"
                )
                .setPositiveButton("Close", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //finish();
                    }
                });
        adb.show();
    }

    //Switch between "Player" and "Trader" view
    void toggleView() {

        viewPrices = !viewPrices;
        setCardText();

    }

    /*
    https://developer.android.com/training/basics/network-ops/connecting.html
    */
    //method to start async task to retrieve card info
    void queryCard(String query) {

        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo ni = cm.getActiveNetworkInfo();

        if (ni != null && ni.isConnected()) {

            new queryToNetwork().execute(query);
            //new queryToNetworkImage().execute(query);

        } else {
            //Toast.makeText(getApplicationContext(), "No network connection available.", Toast.LENGTH_SHORT).show();
            couldNotFindCard();
            Log.d(">", "No network connection available.");
        }

    }

    //async task first attempts to find just the card's properties
    //upon success, it also attempts to find the card's image and prices
    private class queryToNetwork extends AsyncTask<String, Void, String> {

        /*
        http://stackoverflow.com/questions/29465996/how-to-get-json-object-using-httpurlconnection-instead-of-volley
        */
        HttpURLConnection urlConnection;
        String cardQuery = "";

        @Override
        protected String doInBackground(String... urls) {

            StringBuilder result = new StringBuilder();

            //attempt to fetch card properties
            try {
                cardQuery = cardDataUrl + query;

                URL url = new URL(cardQuery);
                urlConnection = (HttpURLConnection) url.openConnection();
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());

                BufferedReader reader = new BufferedReader(new InputStreamReader(in));

                String line;

                while ((line = reader.readLine())!=null) {
                    result.append(line);
                }

                Log.d(">","Result: '" + result + "'");

                card.parseToCard(result.toString());

                if (card.success.equals("success")) {
                    //upon success, attempt to download image and prices

                    /*
                    https://stackoverflow.com/questions/29324347/android-cannot-connect-httpurlconnection-to-get-bitmap
                    */

                    HttpURLConnection urlConnection;

                    //attempt to download image
                    try {

                        cardQuery = cardImageUrl + query;
                        card.cardImage = null;
                        URL imageUrl = new URL(cardQuery);
                        urlConnection = (HttpURLConnection) imageUrl.openConnection();

                        urlConnection.setDoInput(true);
                        urlConnection.connect();

                        InputStream input = urlConnection.getInputStream();
                        Bitmap myBitmap = BitmapFactory.decodeStream(input);
                        card.cardImage = myBitmap;

                        urlConnection.disconnect();

                    } catch (Exception e) {
                        Log.e(">","Error downloading image.");
                        Log.e(">","Query was: " + cardQuery);
                        e.printStackTrace();
                    }

                    //attempt to get prices

                    StringBuilder result2 = new StringBuilder();
                    try {
                        cardQuery = cardPriceUrl + query;

                        URL priceUrl = new URL(cardQuery);
                        urlConnection = (HttpURLConnection) priceUrl.openConnection();
                        InputStream in2 = new BufferedInputStream(urlConnection.getInputStream());

                        BufferedReader reader2 = new BufferedReader(new InputStreamReader(in2));

                        String line2;

                        while ((line2 = reader2.readLine()) != null) {
                            result2.append(line2);
                        }

                        Log.d(">","Card price result: '" + result2 + "'");

                        card.parsePricesToCard(result2.toString());

                    } catch (Exception e){
                        Log.e(">","Could not fetch price for " + card.name);
                        e.printStackTrace();
                    }

                    //attempt to get conversion rate
                    StringBuilder result3 = new StringBuilder();
                    try {
                        String rateQuery = "http://api.fixer.io/latest?symbols=USD,CAD";
                        URL rateUrl = new URL(rateQuery);
                        urlConnection = (HttpURLConnection) rateUrl.openConnection();
                        InputStream in3 = new BufferedInputStream(urlConnection.getInputStream());

                        BufferedReader reader3 = new BufferedReader(new InputStreamReader(in3));

                        String line3;
                        while ((line3 = reader3.readLine()) != null) {
                            result3.append(line3);
                        }
                        Log.d(">","Rate: '" + result3 + "'");

                        //Parse inline
                        JSONObject rateObject_layer1 = new JSONObject(result3.toString());
                        JSONObject rateObject_layer2 = rateObject_layer1.getJSONObject("rates");

                        double rate = (rateObject_layer2.getDouble("USD") / rateObject_layer2.getDouble("CAD"));

                        Log.d(">","Calculated rate: " + String.valueOf(rate));

                        card.updateCadPrices(rate); //insert CAD prices

                    } catch (Exception e) {
                        Log.e(">","Failed to get exchange rate.");
                        e.printStackTrace();
                    }


                } else {

                    Log.e(">","success != success");

                }

            } catch (Exception e) {
                Log.e(">","Could not get card data.");
                e.printStackTrace();
            } finally {
                urlConnection.disconnect();
            }
            return result.toString();
        }

        @Override
        protected void onPostExecute(String result) {
            //upon finishing getting of card info, either display the card or an error popup

            if ((card.success != null) && (card.success.equals("success"))) {
                setCardToView();
            } else {
                couldNotFindCard();
            }
        }
    }

    //displayed when card could not be found (or error when connecting to server)
    //method creates a popup and closing it returns user to previous activity
    void couldNotFindCard() {
        AlertDialog.Builder adb = new AlertDialog.Builder(this);

        if (card.message == null) {
        //if ((!card.message.equals(""))||(!card.message.equals(null))) {
            adb.setMessage("Unable to find card: " + query +
                            "\n\n" +
                            "The server may be down or you searched for a card that should not exist."
            );

        } else {
            adb.setMessage("Unable to find card: " + query +
                            "\n\n" +
                            "The server may be down or you searched for a card that should not exist." +
                            "\n\n" +
                            "Server replied: " + card.message
            );
        }
        adb
                .setTitle("Failed to find card.")
                .setPositiveButton("Go back", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                });
        adb.show();
    }

    //changes the appropriate views with the card info (assumes card has already parsed itself)
    void setCardToView() {
        TextView t;
        ImageView i;

        t = (TextView) findViewById(R.id.cardText);
        t.setText(card.cardText);

        if (card.type.equals("monster")) {
            //monster card only

            i = (ImageView) findViewById(R.id.icon_attribute);
            t = (TextView) findViewById(R.id.text_attribute);

            if (card.attribute.equals("dark")) {
                i.setImageResource(R.drawable.attribute_dark);
                t.setText("Dark");
            } else if (card.attribute.equals("divine")) {
                i.setImageResource(R.drawable.attribute_divine);
                t.setText("Divine");
            } else if (card.attribute.equals("earth")) {
                i.setImageResource(R.drawable.attribute_earth);
                t.setText("Earth");
            } else if (card.attribute.equals("fire")) {
                i.setImageResource(R.drawable.attribute_fire);
                t.setText("Fire");
            } else if (card.attribute.equals("light")) {
                i.setImageResource(R.drawable.attribute_light);
                t.setText("Light");
            } else if (card.attribute.equals("water")) {
                i.setImageResource(R.drawable.attribute_water);
                t.setText("Water");
            } else if (card.attribute.equals("wind")) {
                i.setImageResource(R.drawable.attribute_wind);
                t.setText("Wind");
            }

            i = (ImageView) findViewById(R.id.icon_level_or_property);
            t = (TextView) findViewById(R.id.text_level_or_property);
            i.setImageResource(R.drawable.level);
            t.setText("Level " + String.valueOf(card.level));
            //t.setText("[" + card.monster_type + "]");

            String propText = "";

            //Additional monster properties
            propText = "[" + card.monster_type + "]\n" +
                    "ATK/" + String.valueOf(card.atk) + "\n" +
                    "DEF/" + String.valueOf(card.def);

            t = (TextView) findViewById(R.id.text_additional_properties);
            t.setText(propText);

        } else {
            //spell or trap card

            i = (ImageView) findViewById(R.id.icon_attribute);
            t = (TextView) findViewById(R.id.text_attribute);

            if (card.type.equals("spell")) {
                i.setImageResource(R.drawable.attribute_spell);
                t.setText("Spell card");
            } else if (card.type.equals("trap")) {
                i.setImageResource(R.drawable.attribute_trap);
                t.setText("Trap card");
            } else {
                Log.e(">","Unknown type: " + card.type);
            }

            if (card.property != null) {
                //card contains additional property

                i = (ImageView) findViewById(R.id.icon_level_or_property);
                t = (TextView) findViewById(R.id.text_level_or_property);

                if (card.property.equals("Continuous")) {
                    i.setImageResource(R.drawable.property_continuous);
                    t.setText("Continuous");
                } else if (card.property.equals("Counter")) {
                    i.setImageResource(R.drawable.property_counter);
                    t.setText("Counter");
                } else if (card.property.equals("Equip")) {
                    i.setImageResource(R.drawable.property_equip);
                    t.setText("Equip");
                } else if (card.property.equals("Field")) {
                    i.setImageResource(R.drawable.property_field);
                    t.setText("Field");
                } else if (card.property.equals("Quick-Play")) {
                    i.setImageResource(R.drawable.property_quickplay);
                    t.setText("Quick-play");
                } else if (card.property.equals("Ritual")) {
                    i.setImageResource(R.drawable.property_ritual);
                    t.setText("Ritual");
                }

            } else {
                /*
                https://stackoverflow.com/questions/2859212/how-to-clear-an-imageview-in-android
                 */
                i.setImageResource(android.R.color.transparent);
                t.setText("");
            }

        }

        //set card image
        i = (ImageView) findViewById(R.id.cardImage);

        if (card.cardImage != null) {
            i.setImageBitmap(card.cardImage);
        } else {
            i.setImageResource(R.drawable.card_unknown);
            Toast.makeText(getApplicationContext(), "No image available.", Toast.LENGTH_SHORT).show();
        }

        //set card prices
        t = (TextView) findViewById(R.id.text_avg);
        t.setText("$" + String.valueOf(card.avg) + "  ");
        t = (TextView) findViewById(R.id.text_avg_cad);
        t.setText("$" + new DecimalFormat("####.##").format(card.avg_cad) + " (CAD)");

        t = (TextView) findViewById(R.id.text_low);
        t.setText("$" + String.valueOf(card.low) + "  ");
        t = (TextView) findViewById(R.id.text_low_cad);
        t.setText("$" + new DecimalFormat("####.##").format(card.low_cad) + " (CAD)");

        t = (TextView) findViewById(R.id.text_high);
        t.setText("$" + String.valueOf(card.high) + "  ");
        t = (TextView) findViewById(R.id.text_high_cad);
        t.setText("$" + new DecimalFormat("####.##").format(card.high_cad) + " (CAD)");


        setCardText();
    }

    //Sets the lower half of the screen
    //Content depends on whether the view is set to Player or Trader (boolean viewPrices)
    void setCardText() {

        ScrollView s = (ScrollView) findViewById(R.id.scrollView);
        TableLayout t = (TableLayout) findViewById(R.id.lowerTableView);

        if (viewPrices == false) {
            //Player view; show card text
            s.setVisibility(View.VISIBLE);
            t.setVisibility(View.GONE);

        } else {
            //Trader view; show prices
            s.setVisibility(View.GONE);
            t.setVisibility(View.VISIBLE);

        }
    }

}
